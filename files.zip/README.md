# Auto-Shorts: Video → TikTok + Instagram

## What's in this package
- `n8n-auto-shorts-workflow.json` — import into n8n Cloud (Workflows → Import from File)
- `ffmpeg-shorts-service/` — a small server you deploy separately; n8n calls it over HTTP to do the actual video cutting/cropping/captioning (n8n Cloud can't run ffmpeg itself)

## 1. Deploy the ffmpeg microservice
Pick one (all have free/cheap tiers):
- **Railway.app** — "New Project" → "Deploy from GitHub" (push this folder to a repo) or "Empty Project" + drag the folder in. It auto-detects the Dockerfile.
- **Render.com** — "New Web Service" → point at the repo → it uses the Dockerfile automatically.
- **Fly.io** — `fly launch` from inside the `ffmpeg-shorts-service` folder.

Once deployed, copy the public URL (e.g. `https://your-app.up.railway.app`) and hit `/health` in a browser to confirm it responds `{"ok":true}`.

## 2. Import the n8n workflow
In n8n Cloud: **Workflows → Import from File** → select `n8n-auto-shorts-workflow.json`.

Open the **Config** node and fill in:
- `FFMPEG_SERVICE_URL` — the URL from step 1
- `IG_USER_ID` — your Instagram Business Account ID (see step 4)
- `CLOUDINARY_CLOUD_NAME` / `CLOUDINARY_UPLOAD_PRESET` — TikTok and Instagram both require a *public* video URL, so rendered clips get uploaded to Cloudinary (free tier) first. Create a free account at cloudinary.com and an unsigned upload preset under Settings → Upload.

## 3. Create credentials in n8n
Go to **Credentials → New** and add:
- **OpenAI API key** (used by the Whisper transcription node and the GPT clip-picker node)
- **HTTP Header Auth** named for TikTok, with header `Authorization: Bearer <your TikTok access token>` — attach it to the "TikTok: Publish Video" node
- **HTTP Header Auth** named for Instagram, with header `Authorization: Bearer <your Meta access token>` — attach it to the two Instagram nodes

## 4. Get TikTok API access
1. Create a developer account at developers.tiktok.com
2. Create an app, add the **Content Posting API** product
3. For personal testing, TikTok allows "unaudited" access with a scope limited to posting as `SELF_ONLY` (only visible to you) until you submit for audit/approval for public posting
4. Generate an access token via TikTok's OAuth flow (you'll need to implement the login/consent redirect once — TikTok doesn't allow purely server-to-server tokens)
5. Note: the workflow currently posts with `privacy_level: SELF_ONLY` — change this once your app is approved for public posting

## 5. Get Instagram API access
1. You need an **Instagram Business or Creator account**, linked to a **Facebook Page**
2. Create an app at developers.facebook.com → add the **Instagram Graph API** product
3. Generate a long-lived Page/User access token with `instagram_content_publish` permission
4. Find your Instagram Business Account ID: `GET https://graph.facebook.com/v20.0/{page-id}?fields=instagram_business_account&access_token=...`
5. For anything beyond testing with your own account, Meta requires **App Review** for the `instagram_content_publish` permission — this can take several days

## Notes / things you may want to adjust
- The GPT node currently doesn't pass per-clip captions into the burned-in subtitles (it's wired to send an empty `captions` array to `/process`). To burn in captions, map the relevant Whisper `segments` that fall inside each clip's start/end window, offset their timestamps to be relative to the clip, and pass them as JSON.
- TikTok's `PULL_FROM_URL` mode requires your domain (Cloudinary in this case) to be verified in your TikTok app settings.
- This workflow processes one clip per iteration of "Loop Over Clips" — fine for 2-5 clips per video; for higher volume you'd want a queue rather than sequential loops (n8n Cloud has execution time limits per workflow run).
